//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Toast++Demo.rc
//
#define IDR_MAINFRAME                   128
#define IDD_TOASTPP_DIALOG              130
#define IDC_POP_TOAST                   1000
#define IDC_CLEAR                       1001
#define IDC_PAYLOADS                    1019
#define IDC_PAYLOAD                     1020
#define IDC_MESSAGES                    1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
