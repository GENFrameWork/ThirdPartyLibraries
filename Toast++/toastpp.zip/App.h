#pragma once

#ifndef __AFXWIN_H__
  #error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"
#include <wrl.h>
#include "Toast++.h"


//Define INotificationActivationCallback for older versions of the Windows SDK
#include <ntverp.h>
#if VER_PRODUCTBUILD < 10011

typedef struct NOTIFICATION_USER_INPUT_DATA
{
  LPCWSTR Key;
  LPCWSTR Value;
}  NOTIFICATION_USER_INPUT_DATA;

MIDL_INTERFACE("53E31837-6600-4A81-9395-75CFFE746F94")
INotificationActivationCallback : public IUnknown
{
public:
    virtual HRESULT STDMETHODCALLTYPE Activate(__RPC__in_string LPCWSTR appUserModelId, __RPC__in_opt_string LPCWSTR invokedArgs,
                                               __RPC__in_ecount_full_opt(count) const NOTIFICATION_USER_INPUT_DATA *data, ULONG count) = 0;
};

#else
#include <NotificationActivationCallback.h>
#endif //#if VER_PRODUCTBUILD < 10011



class CToastPPApp : public CWinApp
{
public:
//Constructors
  CToastPPApp() noexcept;

//Member variables
  int  m_nExitCode;

//Methods
  BOOL InitInstance() override;
  int ExitInstance() override;
  HRESULT RegisterCOMServer(_In_z_ PCWSTR pszExePath) noexcept;
  HRESULT UnRegisterCOMServer() noexcept;
  HRESULT RegisterActivator() noexcept;
  void UnregisterActivator() noexcept;

  DECLARE_MESSAGE_MAP()
};


extern CToastPPApp theApp;


//The COM server which implements the callback notifcation from Action Center
class DECLSPEC_UUID("383803B6-AFDA-4220-BFC3-0DBF810106BF")
  CToastNotificationActivationCallback : public Microsoft::WRL::RuntimeClass<Microsoft::WRL::RuntimeClassFlags<Microsoft::WRL::ClassicCom>, INotificationActivationCallback>
{
public:
//Methods
  HRESULT STDMETHODCALLTYPE Activate(__RPC__in_string LPCWSTR appUserModelId, __RPC__in_opt_string LPCWSTR invokedArgs,
                                     __RPC__in_ecount_full_opt(count) const NOTIFICATION_USER_INPUT_DATA* data, ULONG count) override;
};

#pragma warning(suppress: 26476 26477)
CoCreatableClass(CToastNotificationActivationCallback);
