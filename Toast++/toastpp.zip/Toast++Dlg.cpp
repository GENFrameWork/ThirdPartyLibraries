#include "stdafx.h"
#include "App.h"
#include "Toast++Dlg.h"
#include "Toast++.h"
#include <array>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif //#ifdef _DEBUG


struct ToastPayload
{
  LPCTSTR pszName;
  LPCTSTR pszXML;
};

std::array<ToastPayload, 15> g_ToastPayloads
{ {

{ _T("Basic.xml"),
_T("<toast>\r\n\
 <visual>\r\n\
  <binding template=\"ToastGeneric\">\r\n\
   <text>Hello World</text>\r\n\
   <text>This is a simple toast message</text>\r\n\
  </binding>\r\n\
 </visual>\r\n\
</toast>")
},

{ _T("Blank.xml"),
_T("<toast>\r\n\
 <visual>\r\n\
  <binding template=\"ToastGeneric\">\r\n\
  </binding>\r\n\
 </visual>\r\n\
</toast>")
},

{ _T("BreakingNews.xml"),
_T("<toast launch=\"action=viewStory&amp;storyId=92187\">\r\n\
 <visual>\r\n\
  <binding template=\"ToastGeneric\">\r\n\
   <text>Tortoise beats rabbit in epic race</text>\r\n\
   <text>In a surprising turn of events, Rockstar Rabbit took a nasty crash, allowing Thomas the Tortoise to win the race.</text>\r\n\
   <text placement=\"attribution\">The Animal Times</text>\r\n\
  </binding>\r\n\
 </visual>\r\n\
</toast>")
},

{ _T("Alarm.xml"),
_T("<toast launch=\"action=viewAlarm&amp;alarmId=3\" scenario=\"alarm\">\r\n\
 <visual>\r\n\
  <binding template=\"ToastGeneric\">\r\n\
   <text>Time to wake up!</text>\r\n\
   <text>To prove you're awake, select which of the following fruits is yellow...</text>\r\n\
  </binding>\r\n\
 </visual>\r\n\
 <actions>\r\n\
  <input id=\"answer\" type=\"selection\" defaultInput=\"wrongDefault\">\r\n\
   <selection id=\"wrong\" content=\"Orange\"/>\r\n\
   <selection id=\"wrongDefault\" content=\"Blueberry\"/>\r\n\
   <selection id=\"right\" content=\"Banana\"/>\r\n\
   <selection id=\"wrong\" content=\"Avacado\"/>\r\n\
   <selection id=\"wrong\" content=\"Cherry\"/>\r\n\
  </input>\r\n\
 <action arguments=\"snooze\" content=\"Snooze\"/>\r\n\
 <action arguments=\"dismiss\" content=\"Dismiss\"/>\r\n\
 </actions>\r\n\
</toast>")
},

{ _T("EventInvite.xml"),
_T("<toast launch=\"action=viewEvent&amp;eventId=63851\">\r\n\
 <visual>\r\n\
  <binding template=\"ToastGeneric\">\r\n\
   <text>Surface Launch Party</text>\r\n\
   <text>Studio S / Ballroom</text>\r\n\
   <text>4:00 PM, 10 / 26 / 2015</text>\r\n\
  </binding>\r\n\
 </visual>\r\n\
 <actions>\r\n\
  <input id=\"status\" type=\"selection\" defaultInput=\"yes\">\r\n\
   <selection id=\"yes\" content=\"Going\"/>\r\n\
   <selection id=\"maybe\" content=\"Maybe\"/>\r\n\
   <selection id=\"no\" content=\"Decline\"/>\r\n\
  </input>\r\n\
  <action arguments=\"action= rsvpEvent&amp;eventId=63851\" content=\"RSVP\"/>\r\n\
  <action arguments=\"dismiss\" content=\"Dismiss\"/>\r\n\
 </actions>\r\n\
</toast>")
},

{ _T("FriendRequest.xml"),
_T("<toast launch=\"action=viewFriendRequest&amp;userId=49183\">\r\n\
 <visual>\r\n\
  <binding template=\"ToastGeneric\">\r\n\
   <text>Matt sent you a friend request</text>\r\n\
   <text>Hey, wanna dress up as wizards and ride around on our hoverboards together?</text>\r\n\
   <image placement=\"appLogoOverride\" hint-crop=\"circle\" src=\"file://%EXEPATH%\\64.jpg\"/>\r\n\
  </binding>\r\n\
 </visual>\r\n\
 <actions>\r\n\
  <action content=\"Accept\" arguments=\"action=acceptFriendRequest&amp;userId=49183\"/>\r\n\
  <action content=\"Decline\" arguments=\"action=declineFriendRequest&amp;userId=49183\"/>\r\n\
 </actions>\r\n\
</toast>")
},

{ _T("IncomingCall.xml"),
_T("<toast launch=\"action=answer&amp;callId=938163\" scenario=\"incomingCall\">\r\n\
 <visual>\r\n\
  <binding template=\"ToastGeneric\">\r\n\
   <text>Andrew Bares</text>\r\n\
   <text>Incoming Call - Mobile</text>\r\n\
   <image hint-crop=\"circle\" src=\"file://%EXEPATH%\\100.jpg\"/>\r\n\
  </binding>\r\n\
 </visual>\r\n\
 <actions>\r\n\
  <action content=\"Text reply\" imageUri=\"file://%EXEPATH%\\message.png\" arguments=\"action=textReply&amp;callId=938163\"/>\r\n\
  <action content=\"Reminder\"  imageUri=\"file://%EXEPATH%\\reminder.png\" arguments=\"action=reminder&amp;callId=938163\"/>\r\n\
  <action content=\"Ignore\" imageUri=\"file://%EXEPATH%\\cancel.png\" arguments=\"action=ignore&amp;callId=938163\"/>\r\n\
  <action content=\"Answer\"  imageUri=\"file://%EXEPATH%\\telephone.png\" arguments=\"action=answer&amp;callId=938163\"/>\r\n\
 </actions>\r\n\
</toast>")
},

{ _T("Messaging.xml"),
_T("<toast launch=\"action=openThread&amp;threadId=92187\">\r\n\
 <visual>\r\n\
  <binding template=\"ToastGeneric\">\r\n\
   <text hint-maxLines=\"1\">Jill Bender</text>\r\n\
   <text>Check out where we camped last weekend!It was incredible, wish you could have come on the backpacking trip!</text>\r\n\
   <image placement=\"appLogoOverride\" hint-crop=\"circle\" src=\"file://%EXEPATH%\\65.jpg\"/>\r\n\
   <image placement=\"hero\" src=\"file://%EXEPATH%\\180.jpg\"/>\r\n\
  </binding>\r\n\
 </visual>\r\n\
 <actions>\r\n\
  <input id=\"textBox\" type=\"text\" placeHolderContent=\"reply\"/>\r\n\
  <action content=\"Send\" imageUri=\"file://%EXEPATH%\\send.png\" hint-inputId=\"textBox\" arguments=\"action=reply&amp;threadId=92187\"/>\r\n\
 </actions>\r\n\
</toast>")
},

{ _T("ProgressBar.xml"),
_T("<toast launch=\"action=viewDownload&amp;downloadId=9438108\">\r\n\
 <visual>\r\n\
  <binding template=\"ToastGeneric\">\r\n\
   <text>Downloading this week's new music...</text>\r\n\
   <progress title=\"Katy Perry\" value=\"0.35\" valueStringOverride=\"3/15 songs\" status=\"Downloading...\"/>\r\n\
  </binding>\r\n\
 </visual>\r\n\
 <actions>\r\n\
  <action arguments=\"action=pauseDownload&amp;downloadId=9438108\" content=\"Pause\"/>\r\n\
  <action arguments=\"action=cancelDownload&amp;downloadId=9438108\" content=\"Cancel\"/>\r\n\
 </actions>\r\n\
</toast>")
},

{ _T("PhotoTagged.xml"),
_T("<toast launch=\"action=viewPhoto&amp;photoId=92187\">\r\n\
 <visual>\r\n\
  <binding template=\"ToastGeneric\">\r\n\
   <image placement=\"appLogoOverride\" hint-crop=\"circle\" src=\"file://%EXEPATH%\\66.jpg\"/>\r\n\
   <text>Adam Wilson tagged you in a photo</text>\r\n\
   <text>On top of McClellan Butte - with Andrew Bares</text>\r\n\
   <image src=\"file://%EXEPATH%\\202.jpg\"/>\r\n\
  </binding>\r\n\
 </visual>\r\n\
 <actions>\r\n\
  <action content=\"Like\" arguments=\"likePhoto&amp;photoId=92187\"/>\r\n\
  <action content=\"Comment\" arguments=\"action=commentPhoto&amp;photoId=92187\"/>\r\n\
 </actions>\r\n\
</toast>")
},

{ _T("Reminder.xml"),
_T("<toast launch=\"action=viewEvent&amp;eventId=1983\" scenario=\"reminder\">\r\n\
 <visual>\r\n\
  <binding template=\"ToastGeneric\">\r\n\
   <text>Adaptive Tiles Meeting</text>\r\n\
   <text>Conf Room 2001 / Building 135</text >\r\n\
   <text>10:00 AM - 10:30 AM</text>\r\n\
  </binding>\r\n\
 </visual>\r\n\
 <actions>\r\n\
  <input id=\"snoozeTime\" type=\"selection\" defaultInput=\"15\">\r\n\
   <selection id=\"1\" content=\"1 minute\"/>\r\n\
   <selection id=\"15\" content=\"15 minutes\"/>\r\n\
   <selection id=\"60\" content=\"1 hour\"/>\r\n\
   <selection id=\"240\" content=\"4 hours\"/>\r\n\
   <selection id=\"144\" content=\"1 day\"/>\r\n\
  </input>\r\n\
  <action arguments=\"snooze\" hint-inputId=\"snoozeTime\" content=\"Snooze\"/>\r\n\
  <action arguments=\"dismiss\" content=\"Dismiss\"/>\r\n\
 </actions>\r\n\
</toast>")
},

{ _T("Restaurant.xml"),
_T("<toast launch=\"action=viewRestaurant&amp;restaurantId=92187\">\r\n\
 <visual>\r\n\
  <binding template=\"ToastGeneric\">\r\n\
   <image placement=\"hero\" src=\"file://%EXEPATH%\\Food1.jpg\"/>\r\n\
   <text hint-maxLines=\"1\">New suggested restaurant</text>\r\n\
   <text>There's a popular chinese restaurant near you that we think you'd like!</text>\r\n\
   <image src=\"file://%EXEPATH%\\RestaurantMap.jpg\"/>\r\n\
   <group>\r\n\
    <subgroup>\r\n\
     <text hint-style=\"body\">Pho Licious</text>\r\n\
     <text hint-style=\"captionSubtle\">4.6 stars</text>\r\n\
    </subgroup>\r\n\
    <subgroup hint-textStacking=\"bottom\">\r\n\
     <text hint-style=\"captionSubtle\" hint-wrap=\"true\" hint-align=\"right\">4018 148th Ave NE, Redmond, WA 98052</text>\r\n\
    </subgroup>\r\n\
   </group>\r\n\
  </binding>\r\n\
 </visual>\r\n\
 <actions>\r\n\
  <action content=\"Map\" arguments=\"bingmaps:?q=4018 148th Ave NE, Redmond, WA 98052\" activationType=\"protocol\"/>\r\n\
  <action content=\"Reviews\" arguments=\"action=viewRestaurantReviews&amp;restaurantId=92187\"/>\r\n\
 </actions>\r\n\
</toast>")
},

{ _T("Weather.xml"),
_T("<toast>\r\n\
<visual baseUri=\"Assets/Apps/Weather/\">\r\n\
 <binding template=\"ToastGeneric\">\r\n\
  <text>Today will be sunny with a high of 63 and a low of 42.</text>\r\n\
   <group>\r\n\
    <subgroup hint-weight=\"1\">\r\n\
     <text hint-align=\"center\">Mon</text>\r\n\
     <image src=\"file://%EXEPATH%\\Mostly Cloudy.png\" hint-removeMargin=\"true\"/>\r\n\
     <text hint-align=\"center\">63</text>\r\n\
     <text hint-style=\"captionsubtle\" hint-align=\"center\">42</text>\r\n\
    </subgroup>\r\n\
    <subgroup hint-weight=\"1\">\r\n\
     <text hint-align=\"center\">Tue</text>\r\n\
     <image src=\"file://%EXEPATH%\\Cloudy.png\" hint-removeMargin=\"true\"/>\r\n\
     <text hint-align=\"center\">57</text>\r\n\
     <text hint-style=\"captionsubtle\" hint-align=\"center\">38</text>\r\n\
    </subgroup>\r\n\
    <subgroup hint-weight=\"1\">\r\n\
     <text hint-align=\"center\">Wed</text>\r\n\
     <image src=\"file://%EXEPATH%\\Sunny.png\" hint-removeMargin=\"true\"/>\r\n\
     <text hint-align=\"center\">59</text>\r\n\
     <text hint-style=\"captionsubtle\" hint-align=\"center\">43</text>\r\n\
    </subgroup>\r\n\
    <subgroup hint-weight=\"1\">\r\n\
     <text hint-align=\"center\">Thu</text>\r\n\
     <image src=\"file://%EXEPATH%\\Sunny.png\" hint-removeMargin=\"true\"/>\r\n\
     <text hint-align=\"center\">62</text>\r\n\
     <text hint-style=\"captionsubtle\" hint-align=\"center\">42</text>\r\n\
    </subgroup>\r\n\
    <subgroup hint-weight=\"1\">\r\n\
     <text hint-align=\"center\">Fri</text>\r\n\
     <image src=\"file://%EXEPATH%\\Sunny.png\" hint-removeMargin=\"true\"/>\r\n\
     <text hint-align=\"center\">71</text>\r\n\
     <text hint-style=\"captionsubtle\" hint-align=\"center\">66</text>\r\n\
    </subgroup>\r\n\
   </group>\r\n\
  </binding>\r\n\
 </visual>\r\n\
</toast>")
},

{ _T("Windows 8.1 style toast (ToastText01).xml"),
_T("<toast>\r\n\
 <visual>\r\n\
  <binding template=\"ToastText01\">\r\n\
   <text id=\"1\">bodyText</text>\r\n\
  </binding>\r\n\
 </visual>\r\n\
</toast>")
},

{ _T("Windows 8.1 style toast (ToastImageAndText04).xml"),
_T("<toast>\r\n\
 <visual>\r\n\
  <binding template=\"ToastImageAndText04\">\r\n\
   <image id=\"1\" src=\"file://%EXEPATH%\\IC601609.png\" alt=\"image1\"/>\r\n\
   <text id=\"1\">Lorem upsum dolor sit amet con...</text>\r\n\
   <text id=\"2\">This is the first line</text>\r\n\
   <text id=\"3\">This is the second line</text>\r\n\
  </binding>\r\n\
 </visual>\r\n\
</toast>")
}

} };


#pragma warning(suppress: 26455)
CToastPPDlg::CToastPPDlg(_In_opt_ CWnd* pParent) : CDialog(CToastPPDlg::IDD, pParent),
                                                   m_hIcon(AfxGetApp()->LoadIcon(IDR_MAINFRAME))
{
}

void CToastPPDlg::DoDataExchange(CDataExchange* pDX)
{
  //Let the base class do its thing
  __super::DoDataExchange(pDX);

  DDX_Control(pDX, IDC_PAYLOADS, m_wndPayloads);
  DDX_Control(pDX, IDC_PAYLOAD, m_wndPayload);
  DDX_Text(pDX, IDC_PAYLOAD, m_sPayload);
  DDX_Control(pDX, IDC_MESSAGES, m_wndStatusMessages);
}

#pragma warning(suppress: 26433 26440)
BEGIN_MESSAGE_MAP(CToastPPDlg, CDialog) //NOLINT(modernize-avoid-c-arrays)
  ON_WM_PAINT()
  ON_WM_QUERYDRAGICON()
  ON_BN_CLICKED(IDC_POP_TOAST, &CToastPPDlg::OnPopToast)
  ON_CBN_SELCHANGE(IDC_PAYLOADS, &CToastPPDlg::OnSelchangePayloads)
  ON_EN_CHANGE(IDC_PAYLOAD, &CToastPPDlg::OnChangePayload)
  ON_BN_CLICKED(IDC_CLEAR, &CToastPPDlg::OnClickedClear)
END_MESSAGE_MAP()

BOOL CToastPPDlg::OnInitDialog()
{
  //Let the base class do its thing
  __super::OnInitDialog();

  SetIcon(m_hIcon, TRUE);
  SetIcon(m_hIcon, FALSE);

  //Populate the combo box and edit boxes
  int i = 0;
  for (const auto& payload : g_ToastPayloads)
  {
#pragma warning(suppress: 26486)
    m_wndPayloads.AddString(payload.pszName);
    if (i == 0)
    {
#pragma warning(suppress: 26486)
      m_wndPayload.SetWindowText(payload.pszXML);
      m_wndPayloads.SetCurSel(i);
    }
    ++i;
  }

  //Create the toast manager
#pragma warning(suppress: 26496)
  HRESULT hr = m_ToastManager.Create(L"Naughter.ToastPPDemoApp");
  if (FAILED(hr))
  {
    CString sMsg;
    sMsg.Format(_T("Failed to create Toast manager, Error:0x%08X"), hr);
    AfxMessageBox(sMsg, MB_OK | MB_ICONEXCLAMATION);
    EndDialog(IDCANCEL);
  }

#ifdef _DEBUG
  //Test out the "CContent" class
  ToastPP::CContent content;
  ToastPP::CGenericText text1(L"Hello World", L"en-us");
#pragma warning(suppress: 26489)
  content.m_Visual.m_BindingGeneric.m_Children.push_back(&text1);
  ToastPP::CGenericText text2(L"This is a simple toast message");
  //content.m_Visual.m_BindingGeneric.m_Children.push_back(&text2);
  ToastPP::CAttributionText text3(L"Copyright PJ Naughter");
  //content.m_Visual.m_BindingGeneric.m_Children.push_back(&text3);
  ToastPP::CAdaptiveText text4(L"This is a simple toast message", L"en-us");
  ToastPP::CAdaptiveText text5;
  ToastPP::CAdaptiveText text6(L"This is a simple toast message");
  text4.m_bHintWrap = true;
  text4.m_HintAlign = ToastPP::AdaptiveTextAlign::Left;
  text4.m_HintStyle = ToastPP::AdaptiveTextStyle::Caption;
  text4.m_nHintMinLines = 2;
  text4.m_nHintMaxLines = 4;
  content.m_Visual.m_BindingGeneric.m_Children.push_back(&text4);
  //content.m_Visual.m_sBaseUri = true;
  //content.m_Visual.m_sLanguage = L"en-us";
  //content.m_Visual.m_sBaseUri = L"http://www.naughter.com";
  //content.m_Audio.m_sSrc = L"ms - winsoundevent:Notification.Reminder";
  //content.m_Audio.m_bLoop = true;
  //content.m_Audio.m_bSilent = true;
  GetSystemTime(&content.m_DisplayTimestamp);
  ToastPP::CGenericImage image1(L"file://%EXEPATH%\\64.jpg", ToastPP::ImagePlacement::Inline);
#pragma warning(suppress: 26489)
  image1.m_sAlternateText = L"Alt";
  image1.m_bAddImageQuery = true;
  image1.m_HintCrop = ToastPP::ImageCrop::None;
  content.m_Visual.m_BindingGeneric.m_Children.push_back(&image1);
#pragma warning(suppress: 26489)
  content.m_Visual.m_BindingGeneric.m_AppLogoOverride.m_sSource = L"file://%EXEPATH%\\65.jpg";
  content.m_Visual.m_BindingGeneric.m_AppLogoOverride.m_HintCrop = ToastPP::ImageCrop::Circle;
#pragma warning(suppress: 26489)
  content.m_Visual.m_BindingGeneric.m_AppLogoOverride.m_sAlternateText = L"alt";
#pragma warning(suppress: 26489)
  content.m_Visual.m_BindingGeneric.m_HeroImage.m_sSource = L"file://%EXEPATH%\\65.jpg";
#pragma warning(suppress: 26489)
  content.m_Visual.m_BindingGeneric.m_HeroImage.m_sAlternateText = L"alt";
  content.m_Scenario = ToastPP::Scenario::Alarm;
  content.m_Duration = ToastPP::Duration::Long;
#pragma warning(suppress: 26489)
  content.m_sLaunch = L"Launch";
  ToastPP::CTextBox textbox1;
#pragma warning(suppress: 26489)
  textbox1.m_sId = L"ID1";
#pragma warning(suppress: 26489)
  textbox1.m_sDefaultInput = L"default value";
#pragma warning(suppress: 26489)
  textbox1.m_sPlaceholderContent = L"Bla";
#pragma warning(suppress: 26489)
  textbox1.m_sTitle = L"Button";
#pragma warning(suppress: 26489)
  content.m_Actions.m_Inputs.push_back(&textbox1);
  ToastPP::CButton button1;
#pragma warning(suppress: 26489)
  button1.m_sArguments = L"arg1";
#pragma warning(suppress: 26489)
  button1.m_sContent = L"content";
#pragma warning(suppress: 26489)
  button1.m_sHintInputId = L"ID1";
#pragma warning(suppress: 26489)
  button1.m_sImageUri = L"file://%EXEPATH%\\65.jpg";
#pragma warning(suppress: 26489)
  content.m_Actions.m_Buttons.push_back(&button1);
  ToastPP::CButtonSnooze snooze;
#pragma warning(suppress: 26489)
  snooze.m_sContent = L"My Snooze";
  //content.m_Actions.m_Buttons.push_back(&snooze);
  ToastPP::CButtonDismiss dismiss;
#pragma warning(suppress: 26489)
  dismiss.m_sContent = L"My Dismiss";
  content.m_Actions.m_Buttons.push_back(&dismiss);
  ToastPP::CAdaptiveImage image2(L"file://%EXEPATH%\\64.jpg");
#pragma warning(suppress: 26489)
  image2.m_sAlternateText = L"Alt";
  image2.m_bAddImageQuery = true;
  image2.m_bHintRemoveMargin = true;
  image2.m_HintAlign = ToastPP::AdaptiveImageAlign::Left;
  image2.m_HintCrop = ToastPP::AdaptiveImageCrop::Circle;
  //content.m_Visual.m_BindingGeneric.m_Children.push_back(&image2);
  ToastPP::CContextMenuItem cmenu1;
#pragma warning(suppress: 26489)
  cmenu1.m_sArguments = L"Arguments";
#pragma warning(suppress: 26489)
  cmenu1.m_sContent = L"Argue";
  //content.m_Actions.m_ContextMenuItems.push_back(&cmenu1);
  ToastPP::CProgressBar bar;
#pragma warning(suppress: 26489)
  bar.m_sTitle = L"Title";
#pragma warning(suppress: 26489)
  bar.m_sValue = L"0.5";
#pragma warning(suppress: 26489)
  bar.m_sStatus = L"status";
#pragma warning(suppress: 26489)
  bar.m_sValueStringOverride = L"Katy Perry";
  //content.m_Visual.m_BindingGeneric.m_Children.push_back(&bar);
  ToastPP::CSelectionBox selBox;
#pragma warning(suppress: 26489)
  selBox.m_sDefaultSelectionBoxItemId = L"id1";
#pragma warning(suppress: 26489)
  selBox.m_sId = L"selbox";
#pragma warning(suppress: 26489)
  selBox.m_sTitle = L"Plants";
  ToastPP::CSelectionBoxItem item1;
#pragma warning(suppress: 26489)
  item1.m_sId = L"id1";
#pragma warning(suppress: 26489)
  item1.m_sContent = L"Lettuce";
#pragma warning(suppress: 26489)
  selBox.m_Items.push_back(&item1);
  ToastPP::CSelectionBoxItem item2;
#pragma warning(suppress: 26489)
  item2.m_sId = L"id2";
#pragma warning(suppress: 26489)
  item2.m_sContent = L"Parsnip";
  selBox.m_Items.push_back(&item2);
  content.m_Actions.m_Inputs.push_back(&selBox);
  ToastPP::CAdaptiveSubgroup subgroup1;
  subgroup1.m_nHintWeight = 1;
  subgroup1.m_HintTextStacking = ToastPP::SubgroupTextStacking::Top;
  ToastPP::CAdaptiveText subtext1(L"Mon");
  subtext1.m_HintAlign = ToastPP::AdaptiveTextAlign::Left;
#pragma warning(suppress: 26489)
  subgroup1.m_Children.push_back(&subtext1);
  ToastPP::CAdaptiveSubgroup subgroup2;
  subgroup2.m_nHintWeight = 1;
  ToastPP::CAdaptiveText subtext2(L"Tue");
  subtext2.m_HintAlign = ToastPP::AdaptiveTextAlign::Right;
#pragma warning(suppress: 26489)
  subgroup2.m_Children.push_back(&subtext2);
  ToastPP::CAdaptiveSubgroup subgroup3;
  subgroup3.m_nHintWeight = 1;
  ToastPP::CAdaptiveText subtext3(L"Wed");
#pragma warning(suppress: 26489)
  subgroup3.m_Children.push_back(&subtext3);
  ToastPP::CAdaptiveSubgroup subgroup4;
  subgroup4.m_nHintWeight = 1;
  ToastPP::CAdaptiveText subtext4(L"Thu");
#pragma warning(suppress: 26489)
  subgroup4.m_Children.push_back(&subtext4);
  ToastPP::CAdaptiveSubgroup subgroup5;
  subgroup5.m_nHintWeight = 1;
  ToastPP::CAdaptiveText subtext5(L"Fri");
#pragma warning(suppress: 26489)
  subgroup5.m_Children.push_back(&subtext5);
  ToastPP::CAdaptiveGroup group1;
#pragma warning(suppress: 26489)
  group1.m_Children.push_back(&subgroup1);
  group1.m_Children.push_back(&subgroup2);
  group1.m_Children.push_back(&subgroup3);
  group1.m_Children.push_back(&subgroup4);
  group1.m_Children.push_back(&subgroup5);
  content.m_Visual.m_BindingGeneric.m_Children.push_back(&group1);
  //content.m_Type = ToastPP::ToastImageAndText03;
#pragma warning(suppress: 26489)
  content.m_Visual.m_BindingWin81.m_sText1 = L"Hello world";
#pragma warning(suppress: 26489)
  content.m_Visual.m_BindingWin81.m_sText2 = L"Line 2";
#pragma warning(suppress: 26489)
  content.m_Visual.m_BindingWin81.m_sText3 = L"Line 3";
#pragma warning(suppress: 26489)
  content.m_Visual.m_BindingWin81.m_Image.m_sSource = L"file://%EXEPATH%\\65.jpg";
#pragma warning(suppress: 26489)
  content.m_Visual.m_BindingWin81.m_Image.m_sAlternateText = L"Alternate text";
  std::wstring sXML;
  hr = content.GetContent(sXML);
  ASSERT(SUCCEEDED(hr));
  OutputDebugStringW(sXML.c_str());
#endif //#ifdef _DEBUG

  return TRUE;
}

#pragma warning(suppress: 26434)
void CToastPPDlg::OnPaint()
{
  if (IsIconic())
  {
    CPaintDC dc(this);

#pragma warning(suppress: 26490)
    SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

    //Center icon in client rectangle
    const int cxIcon = GetSystemMetrics(SM_CXICON);
    const int cyIcon = GetSystemMetrics(SM_CYICON);
    CRect rect;
    GetClientRect(&rect);
    const int x = (rect.Width() - cxIcon + 1) / 2;
    const int y = (rect.Height() - cyIcon + 1) / 2;

    //Draw the icon
    dc.DrawIcon(x, y, m_hIcon);
  }
  else
    __super::OnPaint();
}

#pragma warning(suppress: 26434)
HCURSOR CToastPPDlg::OnQueryDragIcon() noexcept
{
#pragma warning(suppress: 26473)
  return static_cast<HCURSOR>(m_hIcon);
}

void CToastPPDlg::OnPopToast()
{
  //Get the values from the UI
  if (!UpdateData(TRUE))
    return;

  //Create the toast
  CStringW sPayload(FixUpImagesInXML(CStringW(m_sPayload)));
  HRESULT hr = m_Toast.Create(sPayload);
  if (FAILED(hr))
  {
    CString sMsg;
    sMsg.Format(_T("Failed to create the toast, Error:%08X\r\n"), hr);
    ReportToastNotification(sMsg, TRUE);
    return;
  }

  //Show the toast
  hr = m_ToastManager.Show(m_Toast, this);
  if (SUCCEEDED(hr))
  {
    ReportToastNotification(_T("Toast shown successfully\r\n"), TRUE);
  }
  else
  {
    CString sMsg;
    sMsg.Format(_T("Failed to show the toast, Error:%08X\r\n"), hr);
    ReportToastNotification(sMsg, TRUE);
  }
}

void CToastPPDlg::ReportToastNotification(_In_z_ LPCTSTR pszDetails, _In_ BOOL bAppend)
{
  if (bAppend)
  {
    const int nLength = m_wndStatusMessages.GetWindowTextLength();
    m_wndStatusMessages.SetSel(nLength, nLength);
    m_wndStatusMessages.ReplaceSel(pszDetails);
  }
  else
    m_wndStatusMessages.SetWindowText(pszDetails);
}

void CToastPPDlg::OnSelchangePayloads()
{
  const int nCurSel = m_wndPayloads.GetCurSel();
  if (nCurSel == CB_ERR)
    return;
#pragma warning(suppress: 26446 26482)
  CString sXML(g_ToastPayloads[nCurSel].pszXML);
  m_wndPayload.SetWindowText(sXML);
}

CStringW CToastPPDlg::FixUpImagesInXML(_In_ const CStringW& sXML)
{
  CStringW sUpdatedXML(sXML);
  std::wstring sModuleName;
  if (FAILED(ToastPP::CManager::GetExecutablePath(sModuleName)))
    return sUpdatedXML;
  ATL::CPathW sPath(sModuleName.c_str());
  if (!sPath.RemoveFileSpec())
    return sUpdatedXML;
  sUpdatedXML.Replace(L"%EXEPATH%", sPath);
  return sUpdatedXML;
}

void CToastPPDlg::OnToastActivated(_In_opt_ ABI::Windows::UI::Notifications::IToastNotification* /*pSender*/, _In_opt_ IInspectable* /*pArgs*/)
{
  CString sMsg(_T("IToastNotification, The user clicked on the toast\r\n"));
  ReportToastNotification(sMsg, TRUE);
}

void CToastPPDlg::OnToastDismissed(_In_opt_ ABI::Windows::UI::Notifications::IToastNotification* /*pSender*/, _In_ ABI::Windows::UI::Notifications::ToastDismissalReason reason)
{
  CString sMsg;
  switch (reason)
  {
    case ABI::Windows::UI::Notifications::ToastDismissalReason_UserCanceled:
    {
      sMsg = _T("IToastNotification, The user dismissed the toast\r\n");
      break;
    }
    case ABI::Windows::UI::Notifications::ToastDismissalReason_ApplicationHidden:
    {
      sMsg = _T("IToastNotification, The application programatically hid the toast\r\n");
      break;
    }
    case ABI::Windows::UI::Notifications::ToastDismissalReason_TimedOut:
    {
      sMsg = _T("IToastNotification, The toast has timed out\r\n");
      break;
    }
    default:
    {
      sMsg.Format(_T("IToastNotification, The toast was dimissed for an unknown reason %d\r\n"), reason);
      break;
    }
  }
  ReportToastNotification(sMsg, TRUE);
}

void CToastPPDlg::OnToastFailed(_In_opt_ ABI::Windows::UI::Notifications::IToastNotification* /*pSender*/, _In_ HRESULT errorCode)
{
  CString sMsg;
  sMsg.Format(_T("IToastNotification, An error occurred with the toast. Error:%08X\r\n"), errorCode);
  ReportToastNotification(sMsg, TRUE);
}

HRESULT CToastPPDlg::VerifyXML(_Inout_ CString& sError)
{
  ATL::CComPtr<IXMLDOMDocument> xml;
  HRESULT hr = xml.CoCreateInstance(__uuidof(DOMDocument60));
  if (FAILED(hr))
    return hr;
  ATL::CComBSTR bstrXML(m_sPayload);
  VARIANT_BOOL bSuccessfull = VARIANT_FALSE;
  hr = xml->loadXML(bstrXML, &bSuccessfull);
  if (FAILED(hr))
    return hr;

  if (bSuccessfull == VARIANT_FALSE)
  {
    ATL::CComPtr<IXMLDOMParseError> parseError;
    hr = xml->get_parseError(&parseError);
    if (FAILED(hr))
      return hr;
    ATL::CComBSTR bstrReason;
    hr = parseError->get_reason(&bstrReason);
    if (FAILED(hr))
      return hr;
    long nErrorCode = 0;
    hr = parseError->get_errorCode(&nErrorCode);
    if (FAILED(hr))
      return hr;
    long nLine = 0;
    hr = parseError->get_line(&nLine);
    if (FAILED(hr))
      return hr;
    long nLinePos = 0;
    hr = parseError->get_linepos(&nLinePos);
    if (FAILED(hr))
      return hr;
    long nFilePos = 0;
    hr = parseError->get_filepos(&nFilePos);
    if (FAILED(hr))
      return hr;
    sError.Format(_T("Error Code: %X, Line: %d, Line position: %d, File Position: %d, Reason: %s"), nErrorCode, nLine, nLinePos, nFilePos, ATL::CW2T(bstrReason.operator wchar_t*()).operator LPTSTR());
    return E_FAIL;
  }

  return S_OK;
}

void CToastPPDlg::OnChangePayload()
{
  if (!UpdateData(TRUE))
    return;

  CString sError;
  const HRESULT hr = VerifyXML(sError);
  if (FAILED(hr))
  {
    CString sMsg;
    sMsg.Format(_T("Failed to verify the XML. Error:%08X, %s\r\n"), hr, sError.GetString());
    ReportToastNotification(sMsg, FALSE);
  }
  else
    ReportToastNotification(_T("Toast content is valid XML\r\n"), FALSE);
}

void CToastPPDlg::OnClickedClear()
{
  m_wndStatusMessages.SetWindowText(_T(""));
}
