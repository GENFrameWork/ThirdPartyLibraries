#include "stdafx.h"
#include "App.h"
#include "Toast++Dlg.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#pragma warning(suppress: 26433 26440)
BEGIN_MESSAGE_MAP(CToastPPApp, CWinApp) //NOLINT(modernize-avoid-c-arrays)
END_MESSAGE_MAP()



class CToastPPCommandLineInfo : public CCommandLineInfo
{
public:
  //Constructors / Destructors
  CToastPPCommandLineInfo() noexcept : m_bRegister(FALSE),
                                       m_bUnRegister(FALSE)
  {
  }

  //Methods
  void ParseParam(const TCHAR* lpszParam, BOOL bFlag, BOOL bLast) override
  {
    if (bFlag)
    {
      CString sParamUpper(lpszParam);
      sParamUpper.MakeUpper();
      if (sParamUpper == _T("REGSERVER"))
      {
        m_bRegister = TRUE;
        m_bUnRegister = FALSE;
      }
      else if (sParamUpper == _T("UNREGSERVER"))
      {
        m_bUnRegister = TRUE;
        m_bRegister = FALSE;
      }
      else
        __super::ParseParam(lpszParam, bFlag, bLast);
    }
    else
      __super::ParseParam(lpszParam, bFlag, bLast);
  };

  //Member variables
  BOOL m_bRegister;
  BOOL m_bUnRegister;
};



CToastPPApp::CToastPPApp() noexcept : m_nExitCode(ERROR_SUCCESS)
{
}

#pragma warning(suppress: 26426)
CToastPPApp theApp;

BOOL CToastPPApp::InitInstance()
{
  //Initialize the Windows Runtime
  Microsoft::WRL::Wrappers::RoInitializeWrapper winRTInitializer(RO_INIT_MULTITHREADED);
  {
    HRESULT hr = winRTInitializer;
    if (FAILED(hr))
    {
      CString sMsg;
      sMsg.Format(_T("Failed to initialize Windows Runtime, Error:0x%08X"), hr);
      AfxMessageBox(sMsg, MB_OK | MB_ICONEXCLAMATION);
      return FALSE;
    }

    //Get the executable path
    std::wstring sModuleName;
    hr = ToastPP::CManager::GetExecutablePath(sModuleName);
    if (FAILED(hr))
    {
      CString sMsg;
      sMsg.Format(_T("Failed to get executable path, Error:0x%08X"), hr);
      AfxMessageBox(sMsg, MB_OK | MB_ICONEXCLAMATION);
      return FALSE;
    }

    //Parse the command line
    CToastPPCommandLineInfo cmdInfo;
    ParseCommandLine(cmdInfo);
    if (cmdInfo.m_bRegister)
    {
      m_nExitCode = RegisterCOMServer(sModuleName.c_str());
      return FALSE;
    }
    else if (cmdInfo.m_bUnRegister)
    {
      m_nExitCode = UnRegisterCOMServer();
      return FALSE;
    }

    //Register for toast notifications
    hr = ToastPP::CManager::RegisterForNotificationSupport(L"Toast++ Demo App", sModuleName.c_str(), L"Naughter.ToastPPDemoApp", __uuidof(CToastNotificationActivationCallback));
    if (FAILED(hr))
    {
      CString sMsg;
      sMsg.Format(_T("Failed to register for Toast Notifications, Error:0x%08X"), hr);
      AfxMessageBox(sMsg, MB_OK | MB_ICONEXCLAMATION);
      return FALSE;
    }

    //Register the class factories
    m_nExitCode = RegisterActivator();
    if (FAILED(hr))
      return FALSE;

    //Bring up the main dialog
    CToastPPDlg mainDlg;
    m_pMainWnd = &mainDlg;
    mainDlg.DoModal();

    UnregisterActivator();
  }

  return FALSE;
}

int CToastPPApp::ExitInstance()
{
  __super::ExitInstance();
  return m_nExitCode;
}

HRESULT CToastPPApp::RegisterCOMServer(_In_z_ PCWSTR pszExePath) noexcept
{
  //In this case, just register this application to start
#pragma warning(suppress: 26472)
  return HRESULT_FROM_WIN32(::RegSetKeyValueW(HKEY_CURRENT_USER, L"SOFTWARE\\Classes\\CLSID\\{383803B6-AFDA-4220-BFC3-0DBF810106BF}\\LocalServer32", nullptr, REG_SZ, pszExePath, static_cast<DWORD>(wcslen(pszExePath)*sizeof(wchar_t))));
}

HRESULT CToastPPApp::UnRegisterCOMServer() noexcept
{
  const HRESULT hr = HRESULT_FROM_WIN32(::RegDeleteKey(HKEY_CURRENT_USER, _T("SOFTWARE\\Classes\\CLSID\\{383803B6-AFDA-4220-BFC3-0DBF810106BF}\\LocalServer32")));
  if (FAILED(hr))
    return hr;
  return HRESULT_FROM_WIN32(::RegDeleteKey(HKEY_CURRENT_USER, _T("SOFTWARE\\Classes\\CLSID\\{383803B6-AFDA-4220-BFC3-0DBF810106BF}")));
}

HRESULT CToastPPApp::RegisterActivator() noexcept
{
#pragma warning(suppress: 4324)
  Microsoft::WRL::Module<Microsoft::WRL::OutOfProc>::Create([]() noexcept {} );
  Microsoft::WRL::Module<Microsoft::WRL::OutOfProc>::GetModule().IncrementObjectCount();
  return Microsoft::WRL::Module<Microsoft::WRL::OutOfProc>::GetModule().RegisterObjects();
}

void CToastPPApp::UnregisterActivator() noexcept
{
  Microsoft::WRL::Module<Microsoft::WRL::OutOfProc>::GetModule().UnregisterObjects();
  Microsoft::WRL::Module<Microsoft::WRL::OutOfProc>::GetModule().DecrementObjectCount();
}

HRESULT CToastNotificationActivationCallback::Activate(__RPC__in_string LPCWSTR appUserModelId, __RPC__in_opt_string LPCWSTR invokedArgs,
                                                       __RPC__in_ecount_full_opt(count) const NOTIFICATION_USER_INPUT_DATA* data, ULONG count)
{
  CStringW sMsg;
  sMsg.Format(L"INotificationActivationCallback, The toast was activated. appUserModelId:\"%s\", Arguments:\"%s\"\r\n", appUserModelId, invokedArgs);
  if (count)
  {
#pragma warning(suppress: 26477)
    ATLASSUME(data != nullptr);
    sMsg += L" Data:\r\n";
    for (ULONG i=0; i<count; i++)
    {
#pragma warning(suppress: 6011 26481 26486)
      sMsg.AppendFormat(L"  Key:\"%s\", Value:\"%s\"\r\n", data[i].Key, data[i].Value);
    }
  }

#pragma warning(suppress: 26466 26489)
  auto pDlg = static_cast<CToastPPDlg*>(theApp.m_pMainWnd);
  if (pDlg == nullptr)
    return S_OK;
  pDlg->ReportToastNotification(CString(sMsg), TRUE);
  return S_OK;
}
